import numpy as np
from numpy import dtype
#opens the ex5data file
file = open("ex5data.txt", "r")

#assigns the head of the file as defined in the question
head = list(file.readline().split()) # makes a list
n = int(head[0]) #no of students
No_Course_of_Work = int(head[1]) # no.of coursework assignment
Course_wt = int(head[2]) #course weightage as mentioned i.e.25%
lineNo_s = 0 # counter for lines of the file
# an initial array to place the elements from file to this array through list
a = np.array([[0, 0, 0, 0, 0]] * n)
# second array to place the calculated values neatly
b = np.array([[0, 0, 0, 0]] * n)

#iterating through the file line by line
for lines in file:
    second_line = list(lines.split())
    a[lineNo_s][0] = int(float(second_line[0]))  # assigns the index 0 of the array as registration number of the student
    a[lineNo_s][1] = int(round(float(second_line[1])))  # assigns the index 1 as exam mark
    a[lineNo_s][2] = int(round(float(second_line[2])))  # assigns index 2 as 1st course work mark
    a[lineNo_s][3] = int(round(float(second_line[3])))# assigns index 3 as 2nd course work mark
    a[lineNo_s][4] = int(round(float(second_line[4])))  # # assigns index 4 as 3rd course work mark
    avgCourseWork_wt = ((a[lineNo_s][2] + a[lineNo_s][3] + a[lineNo_s][4]) / 3) * (Course_wt / 100)  # calculates avg coursework weightage
    avgCourseWork = ((a[lineNo_s][2] + a[lineNo_s][3] + a[lineNo_s][4]) / 3) #calculates avg coursework marks
    overallMark = (a[lineNo_s][1] * (100 - Course_wt) / 100) + avgCourseWork_wt #overall marks calculation

   #Now assigning the second empty array b with the calculated values

    b[lineNo_s][0] = int(second_line[0]) #registration number
    b[lineNo_s][1] = a[lineNo_s][1]      #exam mark
    b[lineNo_s][2] = avgCourseWork       #avg course work marks
    b[lineNo_s][3] = overallMark         #overallmarks
    lineNo_s += 1 # counter to iterate on each line

#Initialization of the final array to assign grades and place in a string

z = np.pad(b, ((0, 0), (0, 1)), mode="constant", constant_values=0)
z = np.array(z, dtype=object)
list = [] #creating an empty list to include elements of int and str type together

#Iterating through the 4th column and 3rd index of the list to assign grades using conditions

for rows, column in np.ndenumerate(z[:, 3]):
    if column > 70:
        list.append("first class student")
    elif column <= 69:
        list.append("Second class grade")
    elif 40 < column < 49:
        list.append("Third class grade")
    else:
        list.append("Failed")
z[:, 4] = list
z = z[z[:, 3].argsort()]  # sorts by the overall marks
print(z)

#To automatically print all the data in the output file
file = open("myOutputFile.txt", "w") #opens file
data = str(z) #converts to str because it doesnt write the int version in text file
file.write(data) #writes in the new file
file.close() #closes the file

print(z, data)
