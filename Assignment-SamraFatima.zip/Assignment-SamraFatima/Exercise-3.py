## Question 3 (a):
def palindrome(x):
    # taking input of the string
    num = input("Please enter a number")
    # storing reverse order of string in another variable
    rev=num[::-1]
    # comparing both input and its reverse  
    if rev==num: 
        #If both input and its reverse is equal,this line returns True
        print("the number is a palindrome",num,True) 
    else:
        #If both input and its reverse is not equal,this line returns False
        print("the number is not a palindrome",False)


## Question 3 (b):
def freq(string):
    # print error messaage if string length is less than 3
    if(len(string) < 3):
        print("length of string is less than 3")
    else:
        # initialze empty dictionary
        freq_dict= dict()
        # convert the string to lower case and iterate string
        for i in string.lower():
            # check if sring is already in dictionary and add if not
            if i not in freq_dict:
                freq_dict[i] = 1
            else:
                freq_dict[i] += 1
        # sort the dictionary and store in list in desending order
        freq_list= sorted(freq_dict.items(), key=lambda x:x[1], reverse=True)
        # get 3rd most occurring item
        x=tuple(freq_list[2])
        print("Character", x[0], "occurred times",x[1])

## Question 3 (c):
def ULD(string):
    string = input("Please enter any sentence in both upper and lower case with atleast 1 or 2 digits")
    # for upper case
    U=0
    # for lower case
    L=0
    # for digits
    D=0
    for i in string:
        # check if charachter is uppercase and increment the variale
        if i.isupper():
                U+=1
        # check if charachter is lowercase and increment the variale        
        elif i.islower():
                L+=1
                print()
        # check if charachter is digit and increment the variale                
        elif i.isdigit():
                D+=1
        else:
        # error message for special and other charachters
            print("unsual charcater")
        # store the data of variables in a tuple
    tuple="Upper case",U,"Lower case",L,"Digits",D
    print(tuple)

