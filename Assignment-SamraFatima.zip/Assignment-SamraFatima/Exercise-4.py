## Question 4 (first part)
from tabulate import tabulate
def mytuple(str,list):
    # sort the list w.r.t. registration number to print in ascending order
    sorted_list = sorted(list, key=lambda t: t[1])
    for i in sorted_list:
        # match the department name entered by user with sorted list
        if str == i[:][2]:
            x=[i[:2]]
            # prints the table in the tabular form
            print(tabulate(x))
# import the OS to read from file on system
import os
File_input=(input("enter the file name"))
#checks if the file exist
if os.path.exists(File_input):
    # open the file
    File=open(File_input)
    #initialized an empty array to store list
    list =[]
    for line in File:
            #appending the tuple elements of file(after converting line to tuple) to the list
            # iterate through the file and append the tuples in list using ' to split
            list.append(tuple(line.strip().split(',')))
    #iterating over list
    for j in list:
        #takes input department from user
        str1 = input("please enter the department ")
        #if the department entered is correct
        if str1!=j[2]:
            print("department doesn't exist, Enter correct department name")
        else:
            #calling the function to execute the program and print the tabular form of the corresponding student and it's reg.no
            mytuple(str1, list)
            input_user = input("would you like to enter another department")
            #take str both in upper and lower case
            if str.upper(input_user) == "YES":
                continue #continue if user says yes else breaks the program
            else:
                break
else:
    #gives error when file not found
    print("Error! file doesnt exist")
