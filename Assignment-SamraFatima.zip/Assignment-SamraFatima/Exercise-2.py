#Defines function with the arguments to take range as an input
def prime_numbers(x,y):
    # takes first number of the range
    x=int(input("please enter the first range: "))
    # takes second number of the range
    y=int(input("please enter the second number: "))
    # Initialized an empty list to append later
    list=[]

#if/else loop for the positive values of the range
    if x < 0 or y + 1 < 0:
        print("Error! Please enter positive numbers")
    else:
        # iterating over the range of numbers input by the user
        for number in range(x,y+1):
            #taking next loop from 2, since 1 is not a prime number
            for i in range(2,number):
                #if the mod of number in the iteration gives 0, program will break and will check next number
                if number%i==0:
                    break
            else:
                #number whose mod is not zero is a prime number and will be appended to list
                list.append(number)
    #to put the prime numbers in the list and 10 numbers per output line,looping over the length of the list stored by the upper loop
    for j in range(0,len(list),10):
        matrix=[list[j:j+10]] #saves first 10 number list in a row
        for l in matrix:
            print(l)
prime_numbers(1,16)
